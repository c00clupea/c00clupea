/**
 *
 * cooclupea Honeypot 
 * <*))><
 *
 * (C) 2014 by Christoph Pohl (c00clupea@googlemail.com)
 * released under the GPLv.2
 * 
 * File:	apatebash.c
 * created: 	Sat Jan 31 16:00:16 2015
 * author:  	Christoph Pohl <c00clupea@gmail.com>
 */
#include "guardian.h"

int main(int argc, char *argv[]){
	  int i;
	  for (i=0; i<26; i++) sym[i] = 0;

	  FILE *myfile = fopen("test.guard", "r");
	  yyin = myfile;
do {
		yyparse();
	} while (!feof(yyin));

	  return 0;
}
