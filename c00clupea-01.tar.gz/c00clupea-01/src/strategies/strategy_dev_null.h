#ifndef STRATEGY_DEV_NULL_H
#define STRATEGY_DEV_NULL_H
#include "../strategy.h"

int strategy_dev_null(struct consumer_command *tmp_cmd);
#endif


