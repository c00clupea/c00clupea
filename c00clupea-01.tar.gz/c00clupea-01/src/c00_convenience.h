#ifndef C00_CONVENIENCE_H
#define C00_CONVENIENCE_H

#define FALSE 0
#define TRUE 1

#endif
