 #!/bin/sh
autoreconf-2.69 --force --install -I config -I m4
