#ifndef UTIL_H
#define UTIL_H
#include <stdio.h>

int print_log(FILE *fp, char *text);


#endif
