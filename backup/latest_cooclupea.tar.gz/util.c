#include "util.h"


int print_log(FILE *fp, char *text){
	if(fp){
		fprintf(fp,text);
	}
}	
